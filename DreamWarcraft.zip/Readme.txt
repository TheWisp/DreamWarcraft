Supported version: 1.26.0.6401

1. Put DreamWarcraft.mix and DreamWarcraftConfig.txt into Warcraft III root folder.
2. Run game, you should see DreamDota version at bottom right of the game.

Config menu can be toggled with hotkey F7 after a match has started.